package com.example.touchassist

import android.content.Context
import android.view.ViewConfiguration
import org.json.JSONArray
import org.json.JSONObject

/** نقطة لمس: الإحداثيات بالبكسل على الشاشة، و t = الزمن بالمللي ثانية من بداية هذا الإصبع. */
data class Pt(val x: Float, val y: Float, val t: Long)

/** مسار إصبع واحد. startOffset = الزمن من بداية التسجيل لحد ما الإصبع نزل. */
class Stroke(val startOffset: Long, val points: List<Pt>) {
    val duration: Long get() = if (points.isEmpty()) 1L else maxOf(points.last().t, 1L)
    val endTime: Long get() = startOffset + duration
}

/** إيماءة محفوظة (Create New Gesture) + إعدادات الماكرو. */
class Gesture(
    val id: String,
    var name: String,
    val strokes: List<Stroke>,
    val screenW: Int,
    val screenH: Int,
    /** false = ينفّذ في نفس المكان المسجّل (ماكرو) | true = تختار المكان قبل التنفيذ (زي iOS) */
    var placeMode: Boolean = false,
    /** عدد مرات التكرار. 0 = بلا نهاية لحد ما توقفه */
    var repeat: Int = 1,
    var repeatDelay: Long = 0L,
    var speed: Float = 1f,
    /** true = كل اللمسات المسجّلة بتتنفّذ في نفس الوقت (ده سلوك iOS الأصلي) | false = بنفس التوقيت اللي اتسجّلت بيه */
    var simultaneous: Boolean = false,
    /** true = دواير ثابتة (Armed): الدواير بتفضل على الشاشة وتنفّذ الإيماءة بضغطة مطوّلة على الزر */
    var armed: Boolean = false,
    /** true = احتفظ بالوقفات زي ما اتسجّلت | false (الافتراضي) = الوقفات الطويلة بتتقلّص عشان الخط يتنفّذ سريع ومايبقاش شبه ضغطة مطوّلة */
    var keepPauses: Boolean = false,
    /** مدة تنفيذ كل خط (مللي ثانية). 0 = زي ما اتسجّل. الافتراضي 100ms (سريع جداً) */
    var strokeMs: Double = 100.0,
    /** مدة اللمس المطوّل على الكورة (مللي). مستقلة عن إعدادات الهاتف */
    var ballLongMs: Double = 500.0,
    /** مهلة الضغطتين على الكورة (مللي) */
    var ballDoubleMs: Double = 300.0,
    /** النقرة على الكورة تتنفّذ فعلاً على التطبيق اللي تحتها بمدة tapMs */
    var tapOn: Boolean = true,
    var tapMs: Double = 50.0,
    /** السحب على الكورة يتنفّذ فعلاً بمدة swipeMs */
    var swipeOn: Boolean = true,
    var swipeMs: Double = 100.0,
    /** المسافة الإضافية حول الكورة التي تعتبر منطقة تأثير/استقبال للمس (dp). */
    var ballEffectDp: Double = 1.0
) {
    /** أوامر الكورة: لمس الكورة نفسها (tap/double/long/up/down/left/right) ← إجراء. "self" = نفّذ الإيماءة دي */
    val ballActions = HashMap<String, String>()

    val totalDuration: Long get() = strokes.maxOfOrNull { it.endTime } ?: 0L

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("w", screenW)
        o.put("h", screenH)
        o.put("place", placeMode)
        o.put("repeat", repeat)
        o.put("delay", repeatDelay)
        o.put("speed", speed.toDouble())
        o.put("sim", simultaneous)
        o.put("armed", armed)
        o.put("keep", keepPauses)
        o.put("sms", strokeMs)
        o.put("blm", ballLongMs)
        o.put("bdm", ballDoubleMs)
        o.put("ton", tapOn)
        o.put("tms", tapMs)
        o.put("son", swipeOn)
        o.put("swm", swipeMs)
        o.put("bed", ballEffectDp)
        val bo = JSONObject()
        for ((k, v) in ballActions) bo.put(k, v)
        o.put("ball", bo)
        val sa = JSONArray()
        for (s in strokes) {
            val so = JSONObject()
            so.put("s", s.startOffset)
            val pa = JSONArray()
            for (p in s.points) {
                pa.put(p.x.toDouble())
                pa.put(p.y.toDouble())
                pa.put(p.t)
            }
            so.put("p", pa)
            sa.put(so)
        }
        o.put("strokes", sa)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Gesture {
            val strokes = ArrayList<Stroke>()
            val sa = o.getJSONArray("strokes")
            for (i in 0 until sa.length()) {
                val so = sa.getJSONObject(i)
                val pa = so.getJSONArray("p")
                val pts = ArrayList<Pt>()
                var j = 0
                while (j + 2 < pa.length()) {
                    pts.add(Pt(pa.getDouble(j).toFloat(), pa.getDouble(j + 1).toFloat(), pa.getLong(j + 2)))
                    j += 3
                }
                if (pts.isNotEmpty()) strokes.add(Stroke(so.getLong("s"), pts))
            }
            val gg = Gesture(
                o.getString("id"),
                o.getString("name"),
                strokes,
                o.getInt("w"),
                o.getInt("h"),
                o.optBoolean("place", false),
                o.optInt("repeat", 1),
                o.optLong("delay", 0L),
                o.optDouble("speed", 1.0).toFloat(),
                o.optBoolean("sim", false),
                o.optBoolean("armed", false),
                o.optBoolean("keep", false),
                o.optDouble("sms", 100.0),
                o.optDouble("blm", 500.0),
                o.optDouble("bdm", 300.0),
                o.optBoolean("ton", true),
                o.optDouble("tms", 50.0),
                o.optBoolean("son", true),
                o.optDouble("swm", 100.0),
                o.optDouble("bed", 1.0)
            )
            val bo = o.optJSONObject("ball")
            if (bo != null) {
                val keys = bo.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    gg.ballActions[k] = bo.getString(k)
                }
            }
            return gg
        }
    }
}

/** سجل كل الإجراءات المتاحة (للقائمة، وللإجراءات المخصصة، وتخصيص القائمة العلوية). */
object Actions {
    private val names = mapOf(
        "none" to "بدون إجراء",
        "menu" to "فتح القائمة",
        "home" to "الشاشة الرئيسية",
        "back" to "رجوع (Back)",
        "notifications" to "مركز الإشعارات",
        "control" to "مركز التحكم",
        "siri" to "المساعد الصوتي",
        "device" to "الجهاز",
        "custom" to "مخصص",
        "gestures" to "إيماءات",
        "lock" to "قفل الشاشة",
        "vol_up" to "رفع الصوت",
        "vol_down" to "خفض الصوت",
        "mute" to "كتم",
        "rotate" to "تدوير الشاشة",
        "lock_rotation" to "قفل التدوير",
        "screenshot" to "لقطة شاشة",
        "recents" to "مبدّل التطبيقات",
        "restart" to "الطاقة / إعادة التشغيل",
        "multitask" to "تعدد المهام",
        "more" to "المزيد",
        "p:double_tap" to "نقر مزدوج",
        "p:long_press" to "ضغطة مطوّلة",
        "p:pinch" to "قرص للداخل",
        "p:pinch_out" to "قرص للخارج",
        "p:pinch_rotate" to "قرص وتدوير",
        "rot_0" to "عمودي",
        "rot_1" to "أفقي ↺",
        "rot_3" to "أفقي ↻",
        "rot_2" to "عمودي مقلوب",
        "newgesture" to "إيماءة جديدة",
        "self" to "تنفيذ هذه الإيماءة",
        "scroll_up" to "تمرير لأعلى",
        "scroll_down" to "تمرير لأسفل",
        "scroll_left" to "تمرير لليسار",
        "scroll_right" to "تمرير لليمين",
        "scroll_top" to "تمرير للحافة العليا",
        "scroll_bottom" to "تمرير للحافة السفلى",
        "scroll_h" to "تمرير أفقي مستمر",
        "scroll_v" to "تمرير رأسي مستمر",
        "camera" to "الكاميرا",
        "move_menu" to "نقل القائمة",
        "access_shortcut" to "اختصار تسهيلات الاستخدام"
    )

    private val pickableBase = listOf(
        "none", "menu", "home", "back", "notifications", "control", "siri",
        "device", "custom", "gestures", "lock", "vol_up", "vol_down", "mute",
        "rotate", "lock_rotation", "screenshot", "recents", "restart", "multitask", "more",
        "p:double_tap", "p:long_press", "p:pinch", "p:pinch_out", "p:pinch_rotate",
        "scroll_up", "scroll_down", "scroll_left", "scroll_right", "scroll_top", "scroll_bottom",
        "scroll_h", "scroll_v", "camera", "move_menu", "access_shortcut"
    )

    val defaultTop = listOf("notifications", "device", "siri", "custom", "control", "home")

    /** كل الإجراءات اللي ينفع تختارها (+ الإيماءات اللي سجلتها). */
    fun pickable(c: Context): List<String> {
        val l = ArrayList(pickableBase)
        for (g in Store.loadGestures(c)) l.add("g:${g.id}")
        return l
    }

    fun label(c: Context, id: String): String {
        if (id.startsWith("cmd:")) {
            val first = id.substring(4).trim().lines().firstOrNull() ?: ""
            return "✍️ " + (if (first.length > 24) first.substring(0, 24) + "…" else first)
        }
        if (id.startsWith("g:")) {
            return Store.loadGestures(c).firstOrNull { it.id == id.substring(2) }?.name ?: "إيماءة محذوفة"
        }
        if (id.startsWith("fingers:")) {
            val n = id.substring(8)
            return if (n == "1") "إصبع" else "$n أصابع"
        }
        if (id.startsWith("swipe:")) {
            val p = id.split(":")
            val n = p.getOrElse(1) { "1" }
            val d = when (p.getOrElse(2) { "up" }) {
                "up" -> "لأعلى"
                "down" -> "لأسفل"
                "left" -> "لليسار"
                else -> "لليمين"
            }
            return "سحب $d"
        }
        return names[id] ?: id
    }
}

/** تخزين بسيط في SharedPreferences. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("touch_assist", Context.MODE_PRIVATE)

    fun loadGestures(c: Context): MutableList<Gesture> {
        val out = ArrayList<Gesture>()
        val raw = sp(c).getString("gestures", null) ?: return out
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) out.add(Gesture.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) {
        }
        return out
    }

    fun saveGestures(c: Context, list: List<Gesture>) {
        val a = JSONArray()
        for (g in list) a.put(g.toJson())
        sp(c).edit().putString("gestures", a.toString()).apply()
    }

    fun upsert(c: Context, g: Gesture) {
        val list = loadGestures(c)
        val idx = list.indexOfFirst { it.id == g.id }
        if (idx >= 0) list[idx] = g else list.add(g)
        saveGestures(c, list)
    }

    fun delete(c: Context, id: String) {
        val list = loadGestures(c)
        list.removeAll { it.id == id }
        saveGestures(c, list)
    }

    // trigger = "single" | "double" | "long"
    fun getAction(c: Context, trigger: String): String {
        val def = if (trigger == "single") "menu" else "none"
        return sp(c).getString("act_$trigger", def) ?: def
    }

    fun setAction(c: Context, trigger: String, action: String) {
        sp(c).edit().putString("act_$trigger", action).apply()
    }

    /** القائمة العلوية (من 1 إلى 8 أيقونات) */
    fun topMenu(c: Context): MutableList<String> {
        val raw = sp(c).getString("top_menu", null) ?: return Actions.defaultTop.toMutableList()
        val l = raw.split(",").filter { it.isNotEmpty() }.toMutableList()
        return if (l.isEmpty()) Actions.defaultTop.toMutableList() else l
    }

    fun setTopMenu(c: Context, l: List<String>) {
        sp(c).edit().putString("top_menu", l.joinToString(",")).apply()
    }

    fun buttonEnabled(c: Context) = sp(c).getBoolean("btn_enabled", true)
    fun setButtonEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("btn_enabled", v).apply()

    fun btnSize(c: Context) = sp(c).getInt("btn_size", 60)
    fun setBtnSize(c: Context, v: Int) = sp(c).edit().putInt("btn_size", v).apply()

    /** شفافية الزر لما تبطّل تستخدمه (15..100) */
    fun idleOpacity(c: Context) = sp(c).getInt("idle_opacity", 40)
    fun setIdleOpacity(c: Context, v: Int) = sp(c).edit().putInt("idle_opacity", v).apply()

    /** مدة الضغطة المطوّلة (مللي ثانية) */
    fun longPressMs(c: Context) = sp(c).getInt("long_ms", ViewConfiguration.getLongPressTimeout())
    fun setLongPressMs(c: Context, v: Int) = sp(c).edit().putInt("long_ms", v).apply()

    /** مهلة الضغطتين (مللي ثانية) */
    fun doubleTapMs(c: Context) = sp(c).getInt("double_ms", ViewConfiguration.getDoubleTapTimeout())
    fun setDoubleTapMs(c: Context, v: Int) = sp(c).edit().putInt("double_ms", v).apply()

    /** هل الضغط على الدواير الثابتة نفسها ينفّذ الإيماءة؟ (افتراضي: لأ، بتتنفّذ بضغطة مطوّلة على الزر) */
    fun tapCircles(c: Context) = sp(c).getBoolean("tap_circles", false)
    fun setTapCircles(c: Context, v: Boolean) = sp(c).edit().putBoolean("tap_circles", v).apply()

    /** مكان الدواير الثابتة لكل إيماءة (إزاحة عن مكان التسجيل) */
    fun getPin(c: Context, id: String): Pair<Float, Float>? {
        val p = sp(c)
        if (!p.contains("pin_x_$id")) return null
        return p.getFloat("pin_x_$id", 0f) to p.getFloat("pin_y_$id", 0f)
    }

    fun setPin(c: Context, id: String, x: Float, y: Float) =
        sp(c).edit().putFloat("pin_x_$id", x).putFloat("pin_y_$id", y).apply()

    /** لون الكورة */
    fun ballColor(c: Context) = sp(c).getInt("ball_color", android.graphics.Color.rgb(57, 255, 20))
    fun setBallColor(c: Context, v: Int) = sp(c).edit().putInt("ball_color", v).apply()

    /** مدة اللمس المطوّل على الكورة نفسها (مللي ثانية، من 0 لـ 10000) */
    fun ballLongMs(c: Context) = sp(c).getInt("ball_long_ms", ViewConfiguration.getLongPressTimeout())
    fun setBallLongMs(c: Context, v: Int) = sp(c).edit().putInt("ball_long_ms", v).apply()

    /** الأوامر الإضافية اللي المستخدم ضافها (ضغط 3 مرات، سحب سريع...) */
    fun extraTriggers(c: Context): Set<String> =
        (sp(c).getString("extra_triggers", "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()

    fun addExtraTrigger(c: Context, t: String) {
        val s = extraTriggers(c).toMutableSet()
        s.add(t)
        sp(c).edit().putString("extra_triggers", s.joinToString(",")).apply()
    }

    fun removeExtraTrigger(c: Context, t: String) {
        val s = extraTriggers(c).toMutableSet()
        s.remove(t)
        sp(c).edit().putString("extra_triggers", s.joinToString(",")).apply()
    }

    /** آخر مكان اتحطت فيه الكورة (إحداثيات الشاشة) — الأهداف المكتوبة بتتنفّذ هناك حتى لو الكورة مخفية */
    fun lastBall(c: Context): Pair<Float, Float>? {
        val p = sp(c)
        if (!p.contains("last_ball_x")) return null
        return p.getFloat("last_ball_x", 0f) to p.getFloat("last_ball_y", 0f)
    }

    fun setLastBall(c: Context, x: Float, y: Float) =
        sp(c).edit().putFloat("last_ball_x", x).putFloat("last_ball_y", y).apply()

    /** حجم الكورة (قطر بالـ dp) */
    fun ballDp(c: Context) = sp(c).getInt("ball_dp", 68)
    fun setBallDp(c: Context, v: Int) = sp(c).edit().putInt("ball_dp", v).apply()

    fun posX(c: Context) = sp(c).getInt("pos_x", -1)
    fun posY(c: Context) = sp(c).getInt("pos_y", -1)
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("pos_x", x).putInt("pos_y", y).apply()
}
